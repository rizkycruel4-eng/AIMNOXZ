package com.zinmods.aimnoxz;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.view.Display;
import android.view.View;
import android.widget.*;
import android.graphics.Point;
import android.content.Context;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("aimnoxz", MODE_PRIVATE);

        TextView refresh = findViewById(R.id.refresh);
        TextView resolution = findViewById(R.id.resolution);
        TextView density = findViewById(R.id.density);
        TextView preset = findViewById(R.id.presetText);

        Display d = getWindowManager().getDefaultDisplay();
        Point p = new Point();
        d.getRealSize(p);
        float dpi = getResources().getDisplayMetrics().densityDpi;

        float hz = 0f;
        if (Build.VERSION.SDK_INT >= 30) hz = d.getRefreshRate();

        refresh.setText(String.format(java.util.Locale.US, "%.0f Hz\nRefresh Rate", hz));
        resolution.setText(p.x + " × " + p.y + "\nResolution");
        density.setText((int)dpi + "\nDensity");

        String presetName = getString(R.string.preset_name);
        preset.setText("AimNoxZ " + presetName);

        findViewById(R.id.startButton).setOnClickListener(v ->
            Toast.makeText(this, "Aim Trainer siap. Mode latihan akan dibuka.", Toast.LENGTH_SHORT).show()
        );

        findViewById(R.id.activationButton).setOnClickListener(v -> showActivation());
        findViewById(R.id.touchButton).setOnClickListener(v ->
            Toast.makeText(this, "Touch test: sentuh dan geser pada area trainer.", Toast.LENGTH_SHORT).show()
        );
    }

    private void showActivation() {
        EditText input = new EditText(this);
        input.setHint("XXXX-XXXX-XXXX");
        new android.app.AlertDialog.Builder(this)
            .setTitle("Activation")
            .setMessage("Masukkan license key produk yang kamu miliki.")
            .setView(input)
            .setNegativeButton("BATAL", null)
            .setPositiveButton("AKTIFKAN", (d, w) -> {
                String key = input.getText().toString().trim();
                if (key.length() >= 8) {
                    prefs.edit().putString("license_key", key).apply();
                    Toast.makeText(this, "Key tersimpan untuk sesi ini.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Format key belum valid.", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }
}
